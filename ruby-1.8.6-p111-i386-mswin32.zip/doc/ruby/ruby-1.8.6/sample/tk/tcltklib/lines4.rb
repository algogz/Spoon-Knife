#! /usr/local/bin/ruby

require "tk"

def drawlines()
  print Time.now, "\n"

  for j in 0 .. 99
    print "*"
    $stdout.flush
    if (j & 1) != 0
      col = "blue"
    else
      col = "red"
    end
    for i in 0 .. 99
#      TkCore::INTERP.__invoke($a.path, "create", "line", i.to_s, '0', '0', (500 - i).to_s, "-fill", col)
    end
  end

  print Time.now, "\n"

  for j in 0 .. 99
    print "*"
    $stdout.flush
    if (j & 1) != 0
      col = "blue"
    else
      col = "red"
    end
    for i in 0 .. 99
      TkCore::INTERP.__invoke($a.path, "create", "line", i.to_s, '0', '0', (500 - i).to_s, "-fill", col)
    end
  end

  print Time.now, "\n"
#  Tk.root.destroy
end

$a = TkCanvas.new{
  height(500)
  width(500)
}

$b = TkButton.new{
  text("draw")
  command(proc{drawlines()})
}

TkPack.configure($a, $b, {"side"=>"left"})

Tk.mainloop

# eof
